% 8.4 kVA
Sn = 8400;
Un = 400;
Fn = 50;
Pp = 2;
Omega = 2*pi*50;
J = 0.1265;
Torquen = Sn/(Omega/Pp);
xd   = 1.8;
xdp  = 0.184;
xdpp = 0.115;
xq   = 0.895;
xqpp = 0.207;
xs   = 0.072;
Tdp  = 0.012;
Tdpp = 0.003;
Tqpp = 0.003;
rs   = 0.0820125;

%% Topogramme et excitation
Ifn = 5;
If0 = 2.04;
coeff_If = (Ifn/If0)-0.5-(1/xq-1/xd); % pour topogramme